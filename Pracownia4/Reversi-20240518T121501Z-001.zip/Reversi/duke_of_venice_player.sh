#!/bin/bash

pypy3 duke_of_venice.py 4
