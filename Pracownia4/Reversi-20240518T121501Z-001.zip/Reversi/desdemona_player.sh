#!/bin/bash

python3 reversi_minmax.py 3
